%  main.m
%  부유식 데이터센터 해수 냉각 시스템
%  월별 최적 취수 수심 및 펌프 전력 계산

set(groot,'defaultAxesFontName','Malgun Gothic');
set(groot,'defaultTextFontName','Malgun Gothic');
set(groot,'defaultLegendFontName','Malgun Gothic');

%% 1. 시스템 상수


Q = 100e6;              % 데이터센터 열부하 [W] = 100 MW
rho = 1025;             % 해수 밀도 [kg/m^3]
Cp = 3980;              % 해수 비열 [J/kg*K]
g = 9.81;               % 중력가속도 [m/s^2]
mu = 0.00108;           % 해수 점성계수 [Pa*s]

D = 0.9;                % 배관 직경 [m]
A = pi*D^2/4;           % 배관 단면적 [m^2]
eta = 0.75;             % 펌프 효율

e = 0.0015/1000;        % HDPE 절대 거칠기 [m]

T_out = 40.0;           % 이론상 최대 출구온도 [degC]

months = [2 4 6 8 10 12];

% 최적화 후보 취수 수심
depths = [0 10 20 30 50 75];

%% 2. 열교환기 조건

% 해수 측 허용 최대 온도 상승
dT_cw_max = 25;         % [degC]

% 기준 유량
Vdot_ref = (Q/(Cp*dT_cw_max))/rho;

%% 3. 배관 및 설비 조건

% 플랫폼과 배출구 사이의 실제 고도차
H_geo = 3.0;            % [m]

% 수심과 무관한 배관 길이
L_fixed = 60;           % [m]

% 밸브, 엘보, 입구/출구 등의 국부손실
K_minor = 8.0;

% 열교환기 압력손실
dp_HX_ref = 90e3;       % [Pa]

% 스트레이너 압력손실
dp_strainer_ref = 15e3; % [Pa]

% 기타 설비 압력손실
dp_other_ref = 20e3;    % [Pa]

%% 4. 월별 수심별 해수 수온

T_sea = [
    11.05, 11.04, 11.05, 10.85, 10.03, 7.11;
    12.78, 12.72, 11.82, 10.49, 4.84, NaN;
    17.87, 14.36, 7.16, 5.82, 3.89, 3.00;
    26.14, 14.29, 12.49, 10.44, 6.35, 3.69;
    18.39, 18.40, 18.41, 18.46, 10.14, 6.01;
    16.11, 15.76, 15.09, 14.70, 11.03, 4.10
];

%% 5. 결과 배열

nMonth = length(months);
nDepth = length(depths);

P_pump       = NaN(nMonth,nDepth);
H_friction   = NaN(nMonth,nDepth);
H_minor      = NaN(nMonth,nDepth);
H_equipment  = NaN(nMonth,nDepth);
H_total      = NaN(nMonth,nDepth);
Vdot         = NaN(nMonth,nDepth);

%% 6. 후보 수심별 계산
for m = 1:nMonth

    for d = 1:nDepth

        T_in = T_sea(m,d);
        z = depths(d);

        [P_pump(m,d), H_friction(m,d), H_minor(m,d), ...
         H_equipment(m,d), H_total(m,d), Vdot(m,d)] = pump_calc( ...
            T_in, z, Q, rho, Cp, g, mu, D, A, eta, e, T_out, ...
            dT_cw_max, Vdot_ref, H_geo, L_fixed, K_minor, ...
            dp_HX_ref, dp_strainer_ref, dp_other_ref);

    end

end

%% 7. 월별 최적 수심 결정

optimal_depth = NaN(nMonth,1);
optimal_power = NaN(nMonth,1);
optimal_head  = NaN(nMonth,1);

for m = 1:nMonth

    valid_idx = find(~isnan(P_pump(m,:)));

    if isempty(valid_idx)
        continue;
    end

    [min_power, local_idx] = min(P_pump(m,valid_idx));

    min_idx = valid_idx(local_idx);

    optimal_depth(m) = depths(min_idx);
    optimal_power(m) = min_power;
    optimal_head(m)  = H_total(m,min_idx);

end

%% 8. 결과 출력

fprintf('\n');
fprintf(' 월별 최적 취수 수심\n');


for m = 1:nMonth

    if isnan(optimal_depth(m))

        fprintf('%2d월 : 운전 가능한 수심 없음\n',months(m));

    else

        fprintf( ...
            '%2d월 : 최적수심 %5.1f m | 펌프전력 %8.2f kW | 총수두 %6.2f m\n', ...
            months(m), optimal_depth(m), optimal_power(m), optimal_head(m));

    end

end


%% 9. 결과 저장


save('01_result.mat', ...
    'Q','rho','Cp','g','mu','D','A','eta','e','T_out', ...
    'months','depths','dT_cw_max','Vdot_ref', ...
    'H_geo','L_fixed','K_minor', ...
    'dp_HX_ref','dp_strainer_ref','dp_other_ref', ...
    'T_sea', ...
    'P_pump', ...
    'H_friction','H_minor','H_equipment','H_total','Vdot', ...
    'optimal_depth','optimal_power','optimal_head');

fprintf('\n');
fprintf('계산 완료: 01_result.mat 저장\n');