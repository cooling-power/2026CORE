%% 01_prepare_100MW_data.m
% Google 전력곡선을 기반으로 100 MW AI 데이터센터 입력데이터 구성

%% 1. 기본 설정

inputFile  = '01_Google_전력곡선_복원데이터.xlsx';

analysis_days = 29;      % 분석기간 [일]
dt_h = 0.25;             % 시간간격 [h] = 15분
N = analysis_days * 24 / dt_h;   % 총 2784개 슬롯
P_target_peak = 100;     % 목표 최대수요전력 [MW]
training_ratio  = 0.60;  % 학습 부하 비율
inference_ratio = 0.40;  % 추론 부하 비율


%% 2. Google 전력 데이터 불러오기

T = readtable(inputFile, 'VariableNamingRule','preserve');

time_raw = T.("경과시간 (일)");
P_raw_MW = T.("Google_전력수요 (MW)");


%% 3. 시간축 구성

slot = (1:N)';
time_hour = (slot - 1) * dt_h;
time_day = time_hour / 24;

% 디지타이징 데이터를 15분 간격으로 보간
P_google_MW = interp1(time_raw, P_raw_MW, time_day, 'linear', 'extrap');


%% 4. 최대수요전력 100 MW로 확대

P_source_peak = max(P_google_MW);
scale_factor = P_target_peak / P_source_peak;

P_100MW_MW = P_google_MW * scale_factor;


%% 5. 학습 부하와 추론 부하 구성

P_train_MW = P_100MW_MW * training_ratio;
P_inf_MW   = P_100MW_MW * inference_ratio;


%% 6. 주요 결과 계산

E_total_MWh = sum(P_100MW_MW) * dt_h;
E_train_MWh = sum(P_train_MW) * dt_h;
E_inf_MWh   = sum(P_inf_MW) * dt_h;

fprintf('\n=== 100 MW 데이터센터 입력데이터 요약 ===\n');
fprintf('분석기간              : %d일\n', analysis_days);
fprintf('시간간격              : 15분\n');
fprintf('시간슬롯 수           : %d개\n', N);
fprintf('확대 전 최대전력      : %.3f MW\n', P_source_peak);
fprintf('확대계수              : %.5f\n', scale_factor);
fprintf('확대 후 최대전력      : %.3f MW\n', max(P_100MW_MW));
fprintf('확대 후 최소전력      : %.3f MW\n', min(P_100MW_MW));
fprintf('확대 후 평균전력      : %.3f MW\n', mean(P_100MW_MW));
fprintf('총 전력사용량         : %.3f MWh\n', E_total_MWh);
fprintf('학습 부하 에너지      : %.3f MWh\n', E_train_MWh);
fprintf('추론 부하 에너지      : %.3f MWh\n', E_inf_MWh);


%% 7. 그래프 생성

% 그림 3. Google 데이터센터 전력곡선
figure('Color','w');
plot(time_day, P_google_MW, 'LineWidth', 0.9);
xlabel('시간 (일)');
ylabel('데이터센터 전력수요 (MW)');
title('Google 데이터센터 전력곡선 복원 결과');
xlim([0 analysis_days]);
grid on;

% 그림 4. 100 MW 규모 데이터센터 전력수요
figure('Color','w');
plot(time_day, P_100MW_MW, 'LineWidth', 0.9);
xlabel('시간 (일)');
ylabel('데이터센터 전력수요 (MW)');
title('100 MW 규모 AI 데이터센터 전력수요');
xlim([0 analysis_days]);
ylim([0 105]);
grid on;

% 그림 5. 학습 및 추론 부하
figure('Color','w');
area(time_day, [P_inf_MW P_train_MW], 'LineStyle','none');
xlabel('시간 (일)');
ylabel('전력수요 (MW)');
title('100 MW 데이터센터의 학습·추론 부하 구성');
legend('추론 부하 (40%)', '학습 부하 (60%)', 'Location','best');
xlim([0 analysis_days]);
ylim([0 105]);
grid on;