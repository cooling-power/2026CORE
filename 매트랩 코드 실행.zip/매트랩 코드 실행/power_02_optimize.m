%% 02_운전시나리오별_최적화.m
% Baseline / ESS Only / Workload Shifting Only / ESS + WS 비교

%% 1. 입력 및 공통 설정

inputFile = '02_100MW_데이터센터_입력데이터.xlsx';

dt = 0.25;                 % 15분
max_delay = 3;             % 45분
facility_cap = 100;        % MW

% 일반용전력(을) 고압B 선택II, 여름철 대표 시나리오
basic_rate = 7380;         % 원/kW
rate_off = 92.1;           % 원/kWh
rate_mid = 144.4;
rate_peak = 225.6;

% ESS
Emax = 40;                 % MWh
Pch_max = 20;              % MW
Pdis_max = 20;             % MW
eta_ch = 0.90;
eta_dis = 0.90;

Emin = 0.20 * Emax;
Einit = 0.50 * Emax;

T = readtable(inputFile,'VariableNamingRule','preserve');

time_day = T.("경과시간 (일)");
time_hour = T.("경과시간 (시간)");

P_total = T.("100MW_전력수요 (MW)");
P_train = T.("학습_전력수요 (MW)");
P_inf = T.("추론_전력수요 (MW)");

N = height(T);

hour = mod(time_hour,24);

is_off = (hour >= 23 | hour < 9);
is_peak = ((hour >= 15 & hour < 17) |  (hour >= 18 & hour < 21));
is_mid = ~(is_off | is_peak);

price = zeros(N,1);

price(is_off) = rate_off;
price(is_mid) = rate_mid;
price(is_peak) = rate_peak;


%% 2. Baseline

Pgrid_base = P_total;
energy_base = sum(Pgrid_base .* price) * 1000 * dt;
peak_base = max(Pgrid_base) * 1000 * basic_rate;
total_base = energy_base + peak_base;


%% 3. ESS Only

Pch = optimvar('Pch',N,1,'LowerBound',0,'UpperBound',Pch_max);
Pdis = optimvar('Pdis',N,1, 'LowerBound',0, 'UpperBound',Pdis_max);
E = optimvar('E',N+1,1,'LowerBound',Emin,'UpperBound',Emax);

Ppeak = optimvar('Ppeak',1,'LowerBound',0);
Pgrid = P_total + Pch - Pdis;
prob = optimproblem('ObjectiveSense','minimize');

prob.Objective = sum(Pgrid .* price) * 1000 * dt  + Ppeak * 1000 * basic_rate;
prob.Constraints.grid_peak = Pgrid <= Ppeak;
prob.Constraints.grid_nonnegative = Pgrid >= 0;
prob.Constraints.ess_initial = E(1) == Einit;

prob.Constraints.ess_state = E(2:end) == E(1:end-1) ...
         + eta_ch * Pch * dt - Pdis * dt / eta_dis;
prob.Constraints.ess_final = E(end) == Einit;

opts = optimoptions('linprog','Display','none');

sol_ess = solve(prob,'Options',opts);

Pgrid_ess = P_total + sol_ess.Pch - sol_ess.Pdis;
energy_ess = sum(Pgrid_ess .* price) * 1000 * dt;
peak_ess = max(Pgrid_ess) * 1000 * basic_rate;

total_ess = energy_ess + peak_ess;


%% 4. Workload Shifting Only

P_train_exec = optimvar('P_train_exec',N,1,'LowerBound',0);

Q = optimvar('Q',N,1,'LowerBound',0);

Ppeak = optimvar('Ppeak',1,'LowerBound',0);

Pgrid = P_inf + P_train_exec;

cum_request = cumsum(P_train) * dt;

prob = optimproblem('ObjectiveSense','minimize');

prob.Objective = sum(Pgrid .* price) * 1000 * dt ...
     + Ppeak * 1000 * basic_rate;

prob.Constraints.grid_peak = Pgrid <= Ppeak;
prob.Constraints.facility_limit = Pgrid <= facility_cap;
prob.Constraints.q_initial =  Q(1) == P_train_exec(1) * dt;
prob.Constraints.q_state = Q(2:end) == Q(1:end-1) ...
         + P_train_exec(2:end) * dt;
prob.Constraints.no_preexecution = ...
          Q <= cum_request;
prob.Constraints.delay_limit = Q(max_delay+1:end) >= ...
         cum_request(1:end-max_delay);
prob.Constraints.training_complete = ...
          Q(end) == cum_request(end);

sol_ws = solve(prob,'Options',opts);

Pgrid_ws =  P_inf + sol_ws.P_train_exec;
energy_ws = sum(Pgrid_ws .* price) * 1000 * dt;
peak_ws = max(Pgrid_ws) * 1000 * basic_rate;
total_ws = energy_ws + peak_ws;

%% 5. ESS + Workload Shifting

P_train_exec = optimvar('P_train_exec',N,1,'LowerBound',0);

Q = optimvar('Q',N,1,'LowerBound',0);

Pch = optimvar('Pch',N,1,'LowerBound',0,'UpperBound',Pch_max);
Pdis = optimvar('Pdis',N,1,'LowerBound',0,'UpperBound',Pdis_max);

E = optimvar('E',N+1,1,'LowerBound',Emin,'UpperBound',Emax);
Ppeak = optimvar('Ppeak',1,'LowerBound',0);

Pgrid = P_inf + P_train_exec + Pch - Pdis;

cum_request = cumsum(P_train) * dt;

prob = optimproblem('ObjectiveSense','minimize');

prob.Objective = sum(Pgrid .* price) * 1000 * dt ...
       + Ppeak * 1000 * basic_rate;
prob.Constraints.grid_peak = Pgrid <= Ppeak;
prob.Constraints.grid_nonnegative = Pgrid >= 0;
prob.Constraints.facility_limit = P_inf + P_train_exec <= facility_cap;

prob.Constraints.q_initial = Q(1) == P_train_exec(1) * dt;

prob.Constraints.q_state =  Q(2:end) == Q(1:end-1) ...
                     + P_train_exec(2:end) * dt;

prob.Constraints.no_preexecution = Q <= cum_request;
prob.Constraints.delay_limit = Q(max_delay+1:end) >= ...
    cum_request(1:end-max_delay);

prob.Constraints.training_complete = Q(end) == cum_request(end);

prob.Constraints.ess_initial = E(1) == Einit;

prob.Constraints.ess_state = E(2:end) == E(1:end-1) ...
    + eta_ch * Pch * dt  - Pdis * dt / eta_dis;

prob.Constraints.ess_final = E(end) == Einit;

sol_both = solve(prob,'Options',opts);

Pgrid_both = P_inf + sol_both.P_train_exec ...
    + sol_both.Pch - sol_both.Pdis;

energy_both = sum(Pgrid_both .* price) * 1000 * dt;
peak_both = max(Pgrid_both) * 1000 * basic_rate;
total_both = energy_both + peak_both;


%% 6. 시나리오 비교

scenario = ["Baseline""ESS Only""Workload Shifting Only" "ESS + WS"];

max_power = [max(Pgrid_base) max(Pgrid_ess) max(Pgrid_ws) max(Pgrid_both)];
energy_cost = [energy_base energy_ess energy_ws energy_both];
peak_cost = [peak_base peak_ess peak_ws peak_both];
total_cost = [total_base total_ess total_ws total_both];

saving =  total_base - total_cost;
saving_rate = saving / total_base * 100;
Result = table(scenario, max_power, energy_cost, ...
    peak_cost,  total_cost, saving, saving_rate);

Result.Properties.VariableNames = {
    '시나리오'
    '최대 계통전력 (MW)'
    '전력량요금 (원)'
    '최대수요전력 비용 (원)'
    '총 전력비용 (원)'
    '절감액 (원)'
    '절감률 (%)'
    };

disp(Result);


%% 7. 시나리오 비교 그래프

labels = {
    'Baseline'
    'ESS Only'
    'Workload Shifting Only'
    'ESS + WS'
    };

x = 1:4;


% 최대 계통전력 비교
figure('Color','w');

bar(x,max_power);

xticks(x);
xticklabels(labels);

ylabel('최대 계통전력 (MW)');
title('운전 시나리오별 최대 계통전력 비교');

grid on;
box on;


% 총 전력비용 비교
figure('Color','w');

bar(x,total_cost/1e8);

xticks(x);
xticklabels(labels);

ylabel('총 전력비용 (억원)');
title('운전 시나리오별 총 전력비용 비교');

grid on;
box on;


%% 8. 통합 최적화 운전 특성 분석

% Baseline 최대 피크가 발생한 시점을 기준으로
% 전후 24시간, 총 48시간을 확대하여 표시

[~, peak_idx] = max(Pgrid_base);

half_window = round(24/dt);

idx_start = max(1, peak_idx-half_window);
idx_end = min(N, peak_idx+half_window);

idx = idx_start:idx_end;

% 그래프용 시간축
t_plot = time_hour(idx) - time_hour(idx_start);


%% 8-1. 피크 시간대 ESS 운전

% ESS 순출력
% 양수 = 방전, 음수 = 충전
P_ess_net = sol_both.Pdis - sol_both.Pch;

% SOC (%)
SOC = sol_both.E(1:end-1) / Emax * 100;


figure('Color','w','Position',[100 100 900 650]);

tiledlayout(3,1,'TileSpacing','compact','Padding','compact');


% 계통전력 비교
nexttile
plot(t_plot,Pgrid_base(idx),'LineWidth',1.4);
hold on
plot(t_plot,Pgrid_both(idx),'LineWidth',1.5);
ylabel('계통전력 (MW)');
title('피크 시간대 ESS 통합운전');
legend('Baseline','ESS + WS','Location','best');
grid on
box on


% ESS 충방전
nexttile
bar(t_plot,P_ess_net(idx),1);
yline(0,'k');
ylabel('ESS 출력 (MW)');
title('ESS 충·방전');
grid on
box on

% ESS SOC
nexttile
stairs(t_plot,SOC(idx),'LineWidth',1.5);
xlabel('시간 (h)');
ylabel('SOC (%)');
ylim([0 105]);
title('ESS 저장에너지 상태');
grid on
box on