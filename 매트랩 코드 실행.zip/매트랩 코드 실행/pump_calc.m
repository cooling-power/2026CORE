function [P_pump, H_f, H_m, H_eq, H_total, V_dot] = ...
    pump_calc( ...
    T_in, z, ...
    Q, rho, Cp, g, mu, D, A, eta, e, T_out, ...
    dT_cw_max, Vdot_ref, ...
    H_geo, L_fixed, K_minor, ...
    dp_HX_ref, dp_strainer_ref, dp_other_ref)

%% =========================================================
%  펌프 동력 계산 함수
%
%  입력:
%  T_in       : 취수 해수 온도 [degC]
%  z          : 취수 수심 [m]
%
%  출력:
%  P_pump     : 펌프 전력 [kW]
%  H_f        : 직관 마찰손실 [m]
%  H_m        : 국부손실 [m]
%  H_eq       : 설비손실 [m]
%  H_total    : 총 요구수두 [m]
%  V_dot      : 해수 유량 [m^3/s]
%% =========================================================


%% 1. 운전 가능 조건

% 취수 해수 온도가 21.7℃를 초과하면
% 해당 수심은 냉각수로 사용할 수 없는 것으로 처리

if isnan(T_in) || T_in > 21.7

    P_pump = NaN;
    H_f = NaN;
    H_m = NaN;
    H_eq = NaN;
    H_total = NaN;
    V_dot = NaN;

    return;
end


%% 2. 필요한 온도차 계산

delta_T_available = T_out - T_in;

% 허용 온도상승을 25℃로 제한
delta_T = min(delta_T_available, dT_cw_max);


%% 3. 필요한 해수 유량

m_dot = Q/(Cp*delta_T);

V_dot = m_dot/rho;


%% 4. 배관 내 유속

v = V_dot/A;


%% 5. Reynolds 수

Re = rho*v*D/mu;


%% 6. Darcy 마찰계수

f = (-1.8*log10( ...
    (e/D/3.7)^1.11 + 6.9/Re ...
    ))^-2;


%% 7. 직관 마찰손실

L_pipe = L_fixed + z;

H_f = ...
    f*(L_pipe/D)*(v^2/(2*g));


%% 8. 국부손실

H_m = ...
    K_minor*(v^2/(2*g));


%% 9. 설비 압력손실

flow_ratio = V_dot/Vdot_ref;

dp_HX = ...
    dp_HX_ref*flow_ratio^2;

dp_strainer = ...
    dp_strainer_ref*flow_ratio^2;

dp_other = ...
    dp_other_ref*flow_ratio^2;

dp_equipment = ...
    dp_HX + dp_strainer + dp_other;


%% 10. 설비손실 수두

H_eq = ...
    dp_equipment/(rho*g);


%% 11. 총 요구수두

H_total = ...
    H_geo + H_f + H_m + H_eq;


%% 12. 펌프 소비전력

P_pump = ...
    rho*g*V_dot*H_total/(eta*1000);

end