코드를 실행하고자 하신다면
1. 파일 전체를 바탕화면으로 옮겨주세요
2. 매트랩을 실행하고 경로를 이 파일로 지정해주세요
3. 원하는 파트를 아래 순서를 따라 실행시켜주세요


< 냉각시스템 파트 - cooling >
main > baseline > plot 순으로 코드를 실행시켜주세요
pump_calc의 경우 파일 안에 존재하면 될 뿐 실행시키지 않아도 됩니다.

< ESS / Workload Shifting 파트 - power >
prepare > optimize 순으로 코드를 실행시켜주세요