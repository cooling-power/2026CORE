% baseline_result.m
%
%  표층 / 중앙 후보 수심 / 최적 수심 비교
%  및 전력 절감률 계산
%
%  기준:
%  - 표층 기준       : 0 m
%  - 중앙 후보 수심  : 30 m
%  - 최적 수심       : 월별 최소 펌프 전력 수심


%% 1. 기존 계산 결과 불러오기

if ~isfile('01_result.mat')

    error('먼저 main.m을 실행하여 01_result.mat을 생성해주세요.');

end

load('01_result.mat');

%% 2. 기준 수심 설정
% 표층 기준
surface_depth = 0;

% 중앙 후보 수심
% 현재 후보 수심 [0 10 20 30 50 75 m] 중
% 중앙 기준으로 사용할 실제 데이터 수심
middle_depth = 30;

%% 3. 표층 / 중앙 후보 수심 위치 찾기


surface_idx = find(depths == surface_depth, 1);
middle_idx  = find(depths == middle_depth, 1);

if isempty(surface_idx)

    error('depths에 0 m 수심이 없습니다.');

end

if isempty(middle_idx)

    error('depths에 30 m 수심이 없습니다.');

end

%% 4. 표층 및 중앙 후보 수심 펌프 전력

% 이미 main.m에서 계산한 결과를 그대로 사용
P_surface = P_pump(:,surface_idx);

P_middle = P_pump(:,middle_idx);

%% 5. 최적 수심 결과

P_optimal = optimal_power;
Depth_optimal = optimal_depth;

%% 6. 전력 절감률 계산
% 표층 대비 최적 수심 절감률
Saving_surface = (P_surface - P_optimal) ./ P_surface * 100;

% 중앙 후보 수심 대비 최적 수심 절감률
Saving_middle = (P_middle - P_optimal) ./ P_middle * 100;

%% 7. 평균 절감률

Average_surface_saving = mean(Saving_surface,'omitnan');
Average_middle_saving = mean(Saving_middle,'omitnan');

%% 8. 결과표 생성
ResultTable = table(months(:), Depth_optimal, P_surface, ...
    P_middle, P_optimal, Saving_surface, Saving_middle, ...
    'VariableNames', {'월', '최적수심_m', '표층전력_kW', ...
    '중앙후보수심전력_kW', '최적전력_kW', ...
    '표층대비절감률_percent', '중앙후보수심대비절감률_percent'});


%% 9. 결과 출력
fprintf('\n');
fprintf(' 냉각 방식별 펌프 전력 비교\n');
disp(ResultTable);

fprintf('\n');
fprintf(' 평균 전력 절감률\n');
fprintf('표층(0 m) 대비 평균 절감률       : %.2f %%\n', ...
    Average_surface_saving);

fprintf('중앙 후보 수심(30 m) 대비 평균 절감률 : %.2f %%\n', ...
    Average_middle_saving);

%% 10. 목적함수 / 설계변수 / 제약조건
ObjectiveTable = table( ...
    {'목적함수'; '설계변수'; '제약조건'; '평가값'; '최적해'}, ...
    {'펌프 소비 전력 최소화'; '취수 수심'; '해수 입구온도 ≤ 21.7 ℃'; ...
    '후보 수심별 펌프 소비 전력'; '조건을 만족하면서 펌프 전력이 가장 작은 수심'}, ...
    'VariableNames', {'구분','내용'});

fprintf('\n');
fprintf(' 최적화 조건\n');

disp(ObjectiveTable)

%% 11. 결과 저장
save('03_baseline_result.mat', 'surface_depth', 'middle_depth', ...
    'P_surface', 'P_middle', 'P_optimal', 'Depth_optimal', ...
    'Saving_surface', 'Saving_middle', 'Average_surface_saving', ...
    'Average_middle_saving', 'ResultTable', 'ObjectiveTable');

fprintf('\n');
fprintf(' 베이스라인 비교 완료\n');
fprintf('표층 기준       : %g m\n', surface_depth);
fprintf('중앙 후보 수심  : %g m\n', middle_depth);
fprintf('결과 파일       : 03_baseline_result.mat\n');