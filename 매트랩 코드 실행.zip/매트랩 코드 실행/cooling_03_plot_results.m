%plot_results.m

%  그래프 1:
%  취수 수심에 따른 펌프 전력 변화
%
%  그래프 2:
%  냉각 방식별 펌프 전력 비교
%
%  그래프 3:
%  최적 수심 적용에 따른 전력 절감률

%% 0. 결과 파일 확인

if ~isfile('01_result.mat')

    error('01_main_분석.m을 먼저 실행해주세요.');

end

if ~isfile('03_baseline_result.mat')

    error('03_baseline_compare.m을 먼저 실행해주세요.');

end


%% 결과 불러오기

load('01_result.mat');
load('03_baseline_result.mat');


%% 그래프 기본 설정

set(groot,'defaultAxesFontName','Malgun Gothic');
set(groot,'defaultTextFontName','Malgun Gothic');
set(groot,'defaultLegendFontName','Malgun Gothic');

%% 그래프 1
%  취수 수심에 따른 펌프 전력 변화
figure('Position',[100 100 900 560]);

hold on;
grid on;
box on;

lineStyles = {
    '-o'   % 2월
    '--s'  % 4월
    '-^'   % 6월
    '--d'  % 8월
    '-v'   % 10월
    '--p'  % 12월
};

for m = 1:length(months)

    plot(depths, P_pump(m,:), lineStyles{m}, ...
        'LineWidth',1.7, 'MarkerSize',6,'MarkerFaceColor','white');

end

xlabel('취수 수심 (m)', 'FontSize',12);
ylabel('펌프 소비 전력 (kW)',  'FontSize',12);
title('취수 수심에 따른 펌프 전력 변화', 'FontSize',15, ...
    'FontWeight','bold');
legend(arrayfun(@(x)sprintf('%d월',x), ...
    months,'UniformOutput',false), 'Location','best', 'NumColumns',2);
set(gca,'FontSize',11);
xlim([0 75]);
hold off;

%% 그래프 2
%  표층 / 중앙 수심 / 최적 수심 비교
ComparisonPower = [P_surface, P_middle, P_optimal];
figure('Position',[120 120 950 560]);
b = bar(months, ComparisonPower, 'grouped', 'BarWidth',0.75);
grid on;
box on;
xlabel('월', 'FontSize',12);
ylabel('펌프 소비 전력 (kW)', 'FontSize',12);
title('냉각 방식별 펌프 전력 비교', 'FontSize',15, 'FontWeight','bold');
legend('표층 취수 (0 m)', sprintf('중앙 수심 취수 (%.0f m)',middle_depth), ...
    '최적 수심 취수', 'Location','best');
set(gca,'FontSize',11);

for k = 1:length(b)

    x = b(k).XEndPoints;
    y = b(k).YEndPoints;

    for j = 1:length(x)

        if ~isnan(y(j))

            text( x(j), y(j), sprintf('%.1f',y(j)), ...
                'HorizontalAlignment','center', ...
                'VerticalAlignment','bottom', 'FontSize',8);

        end

    end

end

%% 그래프 3
%  최적 수심 적용에 따른 전력 절감률
SavingData = [Saving_surface, Saving_middle];
figure('Position',[140 140 950 560]);
b2 = bar(months, SavingData, 'grouped', 'BarWidth',0.75);
grid on;
box on;
xlabel('월', 'FontSize',12);
ylabel('전력 절감률 (%)', 'FontSize',12);
title('최적 수심 적용에 따른 전력 절감률', ...
    'FontSize',15, 'FontWeight','bold');
legend( '표층 대비', sprintf('중앙 수심 대비 (%.0f m)',middle_depth), ...
    'Location','best');
set(gca,'FontSize',11);
yline(0,'k-','LineWidth',1,'HandleVisibility','off');

%% 절감률 표시

for k = 1:length(b2)

    x = b2(k).XEndPoints;
    y = b2(k).YEndPoints;

    for j = 1:length(x)

        if ~isnan(y(j))

            text( x(j),y(j), sprintf('%.2f%%',y(j)), ...
                'HorizontalAlignment','center', ...
                'VerticalAlignment','bottom', 'FontSize',8);

        end

    end

end

hold off;
fprintf('\n');
fprintf('=============================================\n');
fprintf('=============================================\n');
fprintf('1. 취수 수심에 따른 펌프 전력 변화\n');
fprintf('2. 냉각 방식별 펌프 전력 비교\n');
fprintf('3. 최적 수심 적용에 따른 전력 절감률\n');
